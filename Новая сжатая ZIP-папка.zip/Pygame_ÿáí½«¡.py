import pygame

pygame.init()
screen = pygame.display.set_mode((1000, 1000))
pygame.display.set_caption('')
fon = pygame.image.load('фон_0.png')
walls = pygame.image.load('стены_0.png')
run = True
while run:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
    screen.fill((0, 0, 0))
    screen.blit(fon, (0,0))
    screen.blit(walls, (46, 0))
    pygame.display.flip()

pygame.quit()
